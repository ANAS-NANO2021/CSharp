﻿
namespace SuperMarket_Projesi
{
    partial class Catagory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Catagory));
            this.panel1 = new System.Windows.Forms.Panel();
            this.CatagortTb1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.CataDetails = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.CataName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.CataId = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.bunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.GuncelleBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.EkleButton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CatagortTb1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkOrange;
            this.panel1.Controls.Add(this.CatagortTb1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.bunifuThinButton22);
            this.panel1.Controls.Add(this.GuncelleBtn);
            this.panel1.Controls.Add(this.EkleButton);
            this.panel1.Controls.Add(this.CataDetails);
            this.panel1.Controls.Add(this.CataName);
            this.panel1.Controls.Add(this.CataId);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(98, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(699, 426);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // CatagortTb1
            // 
            this.CatagortTb1.BackgroundColor = System.Drawing.Color.White;
            this.CatagortTb1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CatagortTb1.Location = new System.Drawing.Point(319, 88);
            this.CatagortTb1.Name = "CatagortTb1";
            this.CatagortTb1.Size = new System.Drawing.Size(377, 335);
            this.CatagortTb1.TabIndex = 29;
            this.CatagortTb1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CatagortTb1_CellContentClick);
            this.CatagortTb1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CatagortTb1_RowHeaderMouseClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(208, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(250, 33);
            this.label1.TabIndex = 28;
            this.label1.Text = "Katagoriler YÖNET";
            // 
            // CataDetails
            // 
            this.CataDetails.BackColor = System.Drawing.Color.DarkOrange;
            this.CataDetails.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CataDetails.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.CataDetails.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CataDetails.HintForeColor = System.Drawing.Color.Empty;
            this.CataDetails.HintText = "";
            this.CataDetails.isPassword = false;
            this.CataDetails.LineFocusedColor = System.Drawing.Color.Blue;
            this.CataDetails.LineIdleColor = System.Drawing.Color.White;
            this.CataDetails.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.CataDetails.LineThickness = 3;
            this.CataDetails.Location = new System.Drawing.Point(97, 250);
            this.CataDetails.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CataDetails.Name = "CataDetails";
            this.CataDetails.Size = new System.Drawing.Size(126, 36);
            this.CataDetails.TabIndex = 21;
            this.CataDetails.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.CataDetails.OnValueChanged += new System.EventHandler(this.CataDetails_OnValueChanged);
            // 
            // CataName
            // 
            this.CataName.BackColor = System.Drawing.Color.DarkOrange;
            this.CataName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CataName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.CataName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CataName.HintForeColor = System.Drawing.Color.Empty;
            this.CataName.HintText = "";
            this.CataName.isPassword = false;
            this.CataName.LineFocusedColor = System.Drawing.Color.Blue;
            this.CataName.LineIdleColor = System.Drawing.Color.White;
            this.CataName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.CataName.LineThickness = 3;
            this.CataName.Location = new System.Drawing.Point(97, 176);
            this.CataName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CataName.Name = "CataName";
            this.CataName.Size = new System.Drawing.Size(126, 36);
            this.CataName.TabIndex = 19;
            this.CataName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.CataName.OnValueChanged += new System.EventHandler(this.CataName_OnValueChanged);
            // 
            // CataId
            // 
            this.CataId.BackColor = System.Drawing.Color.DarkOrange;
            this.CataId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CataId.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.CataId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CataId.HintForeColor = System.Drawing.Color.Empty;
            this.CataId.HintText = "";
            this.CataId.isPassword = false;
            this.CataId.LineFocusedColor = System.Drawing.Color.Blue;
            this.CataId.LineIdleColor = System.Drawing.Color.White;
            this.CataId.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.CataId.LineThickness = 3;
            this.CataId.Location = new System.Drawing.Point(97, 104);
            this.CataId.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CataId.Name = "CataId";
            this.CataId.Size = new System.Drawing.Size(126, 30);
            this.CataId.TabIndex = 18;
            this.CataId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(3, 270);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "Açıklama";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(6, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 25);
            this.label4.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(3, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = " Adı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(6, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = " ID";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkOrange;
            this.button3.Location = new System.Drawing.Point(-2, 100);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 32);
            this.button3.TabIndex = 7;
            this.button3.Text = "Ürünler";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DarkOrange;
            this.button2.Location = new System.Drawing.Point(-2, 153);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 32);
            this.button2.TabIndex = 6;
            this.button2.Text = " Satış";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // bunifuThinButton22
            // 
            this.bunifuThinButton22.ActiveBorderThickness = 1;
            this.bunifuThinButton22.ActiveCornerRadius = 20;
            this.bunifuThinButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton22.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton22.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton22.BackColor = System.Drawing.Color.DarkOrange;
            this.bunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton22.BackgroundImage")));
            this.bunifuThinButton22.ButtonText = "Sil";
            this.bunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton22.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton22.ForeColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton22.IdleBorderThickness = 1;
            this.bunifuThinButton22.IdleCornerRadius = 20;
            this.bunifuThinButton22.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton22.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton22.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton22.Location = new System.Drawing.Point(181, 355);
            this.bunifuThinButton22.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.bunifuThinButton22.Name = "bunifuThinButton22";
            this.bunifuThinButton22.Size = new System.Drawing.Size(71, 34);
            this.bunifuThinButton22.TabIndex = 26;
            this.bunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton22.Click += new System.EventHandler(this.bunifuThinButton22_Click);
            // 
            // GuncelleBtn
            // 
            this.GuncelleBtn.ActiveBorderThickness = 1;
            this.GuncelleBtn.ActiveCornerRadius = 20;
            this.GuncelleBtn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.GuncelleBtn.ActiveForecolor = System.Drawing.Color.White;
            this.GuncelleBtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.GuncelleBtn.BackColor = System.Drawing.Color.DarkOrange;
            this.GuncelleBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GuncelleBtn.BackgroundImage")));
            this.GuncelleBtn.ButtonText = "Güncelle";
            this.GuncelleBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GuncelleBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GuncelleBtn.ForeColor = System.Drawing.Color.Transparent;
            this.GuncelleBtn.IdleBorderThickness = 1;
            this.GuncelleBtn.IdleCornerRadius = 20;
            this.GuncelleBtn.IdleFillColor = System.Drawing.Color.White;
            this.GuncelleBtn.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.GuncelleBtn.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.GuncelleBtn.Location = new System.Drawing.Point(83, 355);
            this.GuncelleBtn.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.GuncelleBtn.Name = "GuncelleBtn";
            this.GuncelleBtn.Size = new System.Drawing.Size(86, 34);
            this.GuncelleBtn.TabIndex = 25;
            this.GuncelleBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.GuncelleBtn.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // EkleButton
            // 
            this.EkleButton.ActiveBorderThickness = 1;
            this.EkleButton.ActiveCornerRadius = 20;
            this.EkleButton.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.EkleButton.ActiveForecolor = System.Drawing.Color.White;
            this.EkleButton.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.EkleButton.BackColor = System.Drawing.Color.DarkOrange;
            this.EkleButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EkleButton.BackgroundImage")));
            this.EkleButton.ButtonText = "Ekle";
            this.EkleButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EkleButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EkleButton.ForeColor = System.Drawing.Color.Transparent;
            this.EkleButton.IdleBorderThickness = 1;
            this.EkleButton.IdleCornerRadius = 20;
            this.EkleButton.IdleFillColor = System.Drawing.Color.White;
            this.EkleButton.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.EkleButton.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.EkleButton.Location = new System.Drawing.Point(0, 355);
            this.EkleButton.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.EkleButton.Name = "EkleButton";
            this.EkleButton.Size = new System.Drawing.Size(80, 34);
            this.EkleButton.TabIndex = 23;
            this.EkleButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EkleButton.Click += new System.EventHandler(this.EkleButton_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DarkOrange;
            this.button1.Location = new System.Drawing.Point(-4, 51);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 32);
            this.button1.TabIndex = 8;
            this.button1.Text = "Faturalar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Catagory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel1);
            this.Name = "Catagory";
            this.Text = " Katagori";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CatagortTb1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton22;
        private Bunifu.Framework.UI.BunifuThinButton2 GuncelleBtn;
        private Bunifu.Framework.UI.BunifuThinButton2 EkleButton;
        private Bunifu.Framework.UI.BunifuMaterialTextbox CataDetails;
        private Bunifu.Framework.UI.BunifuMaterialTextbox CataName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox CataId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView CatagortTb1;
        private System.Windows.Forms.Button button1;
    }
}